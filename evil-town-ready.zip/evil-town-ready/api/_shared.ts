type DepartmentKey = "police" | "ems" | "gang" | "justice";

const WEBHOOKS: Record<DepartmentKey, string> = {
  police: "https://discord.com/api/webhooks/1482078190917783695/nsqR6Cj30t3UMnsZknOePIUA636TPZC7i2hWD80bZ2YyVeVfOPIB0aqJzJ-M6kGAcRzr",
  ems: "https://discord.com/api/webhooks/1482078290213601512/K-m19EBfzO6pNzSCGJTbJjLXLYKTz-cyVFQ4sDwJlrKYW3l28IJd9R_PQfPwUHxlhvoE",
  gang: "https://discord.com/api/webhooks/1482079018013687849/EcGyKKXrwlz8u_3WaZRfiEy4_Yt1lF7P-t1x9iCls2YIUxqdNacPbhg0zhSui5yZQ0rW",
  justice: "https://discord.com/api/webhooks/1482089354225516686/-XncLMZUcRMQOuy_oKYonMOWxNldmFzAmGY2q9-daLH4en0BS30Si_k7xOv4zPL_DAaU",
};

export const COLORS: Record<DepartmentKey, number> = {
  police: 3447003,
  ems: 15158332,
  gang: 10181046,
  justice: 15844367,
};

export const LABELS: Record<DepartmentKey, string> = {
  police: "Police Department",
  ems: "EMS Department",
  gang: "Gang Application",
  justice: "Justice Department",
};

export const CHARACTER_WEBHOOK = process.env.CHARACTER_WEBHOOK_URL || "";

export const corsHeaders = {
  "Content-Type": "application/json",
};

const MAX_FIELD = 1000;

export const sanitize = (value: unknown, fallback = "Not provided") => {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  if (!trimmed) return fallback;
  return trimmed.length > MAX_FIELD ? `${trimmed.slice(0, MAX_FIELD - 3)}...` : trimmed;
};

export const getDepartmentWebhook = (department: string) => WEBHOOKS[department as DepartmentKey] || "";
