import { CHARACTER_WEBHOOK, corsHeaders, sanitize } from "./_shared";

export default async function handler(req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: corsHeaders });
    }

    const body = await req.json();

    if (!CHARACTER_WEBHOOK) {
      return new Response(
        JSON.stringify({
          error: "Character webhook is not configured",
          message: "Character form is ready, but you still need to add CHARACTER_WEBHOOK_URL.",
        }),
        { status: 500, headers: corsHeaders },
      );
    }

    const payload = {
      embeds: [
        {
          title: "New Character Application",
          color: 5793266,
          fields: [
            { name: "Character Name", value: sanitize(body.name), inline: true },
            { name: "Character Age", value: sanitize(body.age), inline: true },
            { name: "Nationality", value: sanitize(body.nationality), inline: false },
            { name: "Occupation", value: sanitize(body.job), inline: false },
            { name: "Backstory", value: sanitize(body.backstory), inline: false },
          ],
          footer: { text: "Evil Town RP Website" },
          timestamp: new Date().toISOString(),
        },
      ],
    };

    const discordResponse = await fetch(CHARACTER_WEBHOOK, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!discordResponse.ok) {
      return new Response(JSON.stringify({ error: "Failed to send to Discord" }), { status: 500, headers: corsHeaders });
    }

    return new Response(JSON.stringify({ success: true, message: "Character application submitted successfully." }), {
      status: 200,
      headers: corsHeaders,
    });
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: "Server error" }), { status: 500, headers: corsHeaders });
  }
}
