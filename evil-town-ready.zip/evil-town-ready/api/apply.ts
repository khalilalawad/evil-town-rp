import { COLORS, LABELS, corsHeaders, getDepartmentWebhook, sanitize } from "./_shared";

export default async function handler(req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: corsHeaders });
    }

    const body = await req.json();
    const webhook = getDepartmentWebhook(body.department);

    if (!webhook) {
      return new Response(JSON.stringify({ error: "Invalid department" }), { status: 400, headers: corsHeaders });
    }

    const departmentKey = body.department as keyof typeof LABELS;
    const payload = {
      embeds: [
        {
          title: `New ${LABELS[departmentKey]}`,
          color: COLORS[departmentKey],
          fields: [
            { name: "Player Name", value: sanitize(body.name), inline: true },
            { name: "Age", value: sanitize(body.age), inline: true },
            { name: "Discord", value: sanitize(body.discordId), inline: false },
            { name: "Department", value: LABELS[departmentKey], inline: false },
            { name: "RP Experience", value: sanitize(body.experience), inline: false },
            { name: "Why Join", value: sanitize(body.reason), inline: false },
            { name: "Scenario Answer", value: sanitize(body.scenario), inline: false },
            { name: "Backstory", value: sanitize(body.backstory, "N/A"), inline: false },
            { name: "Additional Notes", value: sanitize(body.notes, "N/A"), inline: false },
          ],
          footer: { text: "Evil Town RP Website" },
          timestamp: new Date().toISOString(),
        },
      ],
    };

    const discordResponse = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!discordResponse.ok) {
      return new Response(JSON.stringify({ error: "Failed to send to Discord" }), { status: 500, headers: corsHeaders });
    }

    return new Response(JSON.stringify({ success: true }), { status: 200, headers: corsHeaders });
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: "Server error" }), { status: 500, headers: corsHeaders });
  }
}
