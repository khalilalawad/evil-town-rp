import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Globe } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '@/i18n/LanguageContext';
import logo from '@/assets/evil-town-logo.png';

const Navbar = () => {
  const { lang, setLang, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: t.nav.home, href: isHome ? '#home' : '/', isLink: !isHome },
    { label: t.nav.departments, href: isHome ? '#departments' : '/#departments', isLink: !isHome },
    { label: t.nav.rules, href: '/rules', isLink: true },
    { label: t.nav.applications, href: '/applications', isLink: true },
    { label: t.nav.map, href: '/map', isLink: true },
    { label: t.nav.characters, href: '/characters', isLink: true },
    { label: t.nav.faq, href: '/faq', isLink: true },
  ];

  const renderNavItem = (item: typeof navItems[0]) => {
    const cls = "text-sm text-foreground/70 hover:text-primary transition-colors duration-200";
    if (item.isLink) {
      return <Link key={item.href} to={item.href} className={cls}>{item.label}</Link>;
    }
    return <a key={item.href} href={item.href} className={cls}>{item.label}</a>;
  };

  const renderMobileNavItem = (item: typeof navItems[0]) => {
    const cls = "text-foreground/70 hover:text-primary py-2 transition-colors";
    if (item.isLink) {
      return <Link key={item.href} to={item.href} onClick={() => setIsOpen(false)} className={cls}>{item.label}</Link>;
    }
    return <a key={item.href} href={item.href} onClick={() => setIsOpen(false)} className={cls}>{item.label}</a>;
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass-strong shadow-lg shadow-primary/5' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link to="/" className="flex items-center gap-2.5">
            <img src={logo} alt="Evil Town" className="w-9 h-9 md:w-10 md:h-10 rounded-full" />
            <span className="font-display text-xl md:text-2xl font-bold text-primary text-glow-sm">
              EVIL TOWN
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            {navItems.map(renderNavItem)}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm text-foreground/70 hover:text-foreground border border-border/50 hover:border-primary/30 transition-all"
            >
              <Globe className="w-4 h-4" />
              {lang === 'en' ? 'عربي' : 'EN'}
            </button>
            <a
              href="https://discord.gg/yMMAKZfz"
              target="_blank"
              rel="noopener noreferrer"
              className="gradient-primary px-4 py-2 rounded-md text-sm font-semibold text-primary-foreground hover:opacity-90 transition-opacity"
            >
              {t.nav.joinDiscord}
            </a>
          </div>

          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-foreground">
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-strong border-t border-border/30"
          >
            <div className="container mx-auto px-4 py-4 flex flex-col gap-3">
              {navItems.map(renderMobileNavItem)}
              <div className="flex items-center gap-3 pt-2 border-t border-border/30">
                <button
                  onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm border border-border/50"
                >
                  <Globe className="w-4 h-4" />
                  {lang === 'en' ? 'عربي' : 'EN'}
                </button>
                <a
                  href="https://discord.gg/yMMAKZfz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="gradient-primary px-4 py-2 rounded-md text-sm font-semibold text-primary-foreground flex-1 text-center"
                >
                  {t.nav.joinDiscord}
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;
