import { useLanguage } from '@/i18n/LanguageContext';
import { Link } from 'react-router-dom';
import logo from '@/assets/evil-town-logo.png';

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="border-t border-border/30 bg-card/30">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5 mb-3">
              <img src={logo} alt="Evil Town" className="w-8 h-8 rounded-full" />
              <h3 className="font-display text-2xl font-bold text-primary text-glow-sm">EVIL TOWN</h3>
            </div>
            <p className="text-sm text-muted-foreground max-w-md leading-relaxed">{t.footer.description}</p>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">{t.footer.quickLinks}</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/rules" className="text-muted-foreground hover:text-primary transition-colors">{t.footer.rules}</Link></li>
              <li><Link to="/applications" className="text-muted-foreground hover:text-primary transition-colors">{t.footer.apply}</Link></li>
              <li><Link to="/characters" className="text-muted-foreground hover:text-primary transition-colors">{t.nav.characters}</Link></li>
              <li><Link to="/map" className="text-muted-foreground hover:text-primary transition-colors">{t.nav.map}</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">{t.footer.community}</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="https://discord.gg/yMMAKZfz" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">{t.footer.discord}</a></li>
              <li><Link to="/faq" className="text-muted-foreground hover:text-primary transition-colors">{t.footer.faq}</Link></li>
              <li><Link to="/guide" className="text-muted-foreground hover:text-primary transition-colors">{t.footer.support}</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border/20 text-center">
          <p className="text-xs text-muted-foreground">{t.footer.rights}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
