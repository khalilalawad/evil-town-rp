import { motion } from 'framer-motion';
import { Sparkles, Users, Award, Calendar } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

const icons = [Sparkles, Users, Award, Calendar];

const WhyJoinSection = () => {
  const { t } = useLanguage();

  return (
    <section className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/[0.03] to-background" />
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary text-glow-sm mb-2">
            {t.whyJoin.title}
          </h2>
          <p className="text-muted-foreground">{t.whyJoin.subtitle}</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-5xl mx-auto">
          {t.whyJoin.reasons.map((reason: any, i: number) => {
            const Icon = icons[i];
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
                className="glass rounded-xl p-6 text-center hover:border-primary/30 transition-all duration-300 group"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 group-hover:scale-110 transition-all">
                  <Icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-display text-base font-bold text-foreground mb-2">{reason.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{reason.desc}</p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <a
            href="https://discord.gg/yMMAKZfz"
            target="_blank"
            rel="noopener noreferrer"
            className="gradient-primary px-8 py-3.5 rounded-xl font-display text-sm font-bold text-primary-foreground tracking-wide hover:opacity-90 hover:scale-105 transition-all inline-flex items-center gap-2 box-glow"
          >
            {t.hero.joinNow}
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default WhyJoinSection;
