import { motion } from 'framer-motion';
import { useLanguage } from '@/i18n/LanguageContext';

const LoreSection = () => {
  const { t } = useLanguage();

  return (
    <section id="lore" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/30 to-background" />
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary text-glow-sm mb-2">
            {t.lore.title}
          </h2>
          <p className="text-muted-foreground">{t.lore.subtitle}</p>
        </motion.div>

        <div className="max-w-3xl mx-auto space-y-6">
          {[t.lore.text1, t.lore.text2, t.lore.text3].map((text, i) => (
            <motion.p
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="text-foreground/80 leading-relaxed text-base md:text-lg glass p-6 rounded-xl border-glow"
            >
              {text}
            </motion.p>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LoreSection;
