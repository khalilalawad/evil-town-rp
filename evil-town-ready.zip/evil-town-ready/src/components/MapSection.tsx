import { motion } from 'framer-motion';
import { Map, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/i18n/LanguageContext';
import serverMap from '@/assets/server-map.png';

const MapSection = () => {
  const { t } = useLanguage();

  return (
    <section id="map" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/20 to-background" />
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary text-glow-sm mb-2">
            {t.serverMap.title}
          </h2>
          <p className="text-muted-foreground">{t.serverMap.subtitle}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <div className="glass rounded-2xl overflow-hidden group hover:border-primary/40 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/10">
            {/* Map Image */}
            <div className="relative overflow-hidden">
              <img
                src={serverMap}
                alt="Evil Town Map - Emergency Emden"
                className="w-full h-auto transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-60" />
              <div className="absolute top-4 left-4 rtl:left-auto rtl:right-4 flex items-center gap-2 glass px-3 py-1.5 rounded-lg">
                <Map className="w-4 h-4 text-primary" />
                <span className="text-xs font-display font-bold text-primary">EMERGENCY EMDEN</span>
              </div>
            </div>

            {/* Description */}
            <div className="p-6 md:p-8">
              <p className="text-foreground/80 leading-relaxed mb-5">
                {t.serverMap.description}
              </p>
              <Link
                to="/map"
                className="inline-flex items-center gap-2 gradient-primary px-5 py-2.5 rounded-lg font-display text-sm font-bold text-primary-foreground hover:opacity-90 transition-opacity group/btn"
              >
                {t.serverMap.viewFull}
                <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover/btn:translate-x-1 rtl:group-hover/btn:-translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default MapSection;
