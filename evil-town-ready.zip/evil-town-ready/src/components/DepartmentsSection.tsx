import { motion } from "framer-motion";
import { Shield, Heart, Scale, Skull } from "lucide-react";
import { useLanguage } from "@/i18n/LanguageContext";

const DepartmentsSection = () => {
  const { t } = useLanguage();

  const departments = [
    { icon: Shield, ...t.departments.police, color: "from-blue-500 to-blue-700" },
    { icon: Heart, ...t.departments.ems, color: "from-rose-500 to-rose-700" },
    { icon: Scale, ...t.departments.justice, color: "from-amber-500 to-yellow-700" },
    { icon: Skull, ...t.departments.gangs, color: "from-red-500 to-red-700" },
  ];

  return (
    <section id="departments" className="py-20 md:py-32 relative">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary text-glow-sm mb-2">{t.departments.title}</h2>
          <p className="text-muted-foreground">{t.departments.subtitle}</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {departments.map((dept, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass rounded-xl p-6 group cursor-pointer hover:border-primary/30 transition-all duration-300"
            >
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${dept.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <dept.icon className="w-6 h-6 text-foreground" />
              </div>
              <h3 className="font-display text-lg font-bold text-foreground mb-2">{dept.name}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{dept.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DepartmentsSection;
