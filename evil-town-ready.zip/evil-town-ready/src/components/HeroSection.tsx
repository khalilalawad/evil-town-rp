import { motion } from 'framer-motion';
import { Play, ChevronDown } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { useEffect, useRef, useState } from 'react';
import heroBg from '@/assets/hero-bg.jpg';
import logo from '@/assets/evil-town-logo.png';

const AnimatedCounter = ({ target, label }: { target: string; label: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const num = parseInt(target.replace(/[^0-9]/g, ''));
  const suffix = target.replace(/[0-9]/g, '');

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0;
          const duration = 1500;
          const step = (timestamp: number) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            setCount(Math.floor(progress * num));
            if (progress < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
          observer.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [num]);

  return (
    <div ref={ref} className="text-center">
      <div className="font-display text-2xl md:text-3xl font-bold text-primary text-glow-sm">
        {count}{suffix}
      </div>
      <div className="text-xs md:text-sm text-muted-foreground mt-1">{label}</div>
    </div>
  );
};

const HeroSection = () => {
  const { t } = useLanguage();

  const stats = [
    { value: '500+', label: t.hero.playersOnline },
    { value: '6', label: t.hero.activeDepartments },
    { value: '10000+', label: t.hero.storiesCreated },
  ];

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img src={heroBg} alt="Evil Town" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-primary/5" />
      </div>

      {/* Neon glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-primary/8 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 container mx-auto px-4 text-center pt-20">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
          {/* Logo */}
          <motion.img
            src={logo}
            alt="Evil Town Logo"
            className="w-24 h-24 md:w-32 md:h-32 mx-auto mb-6 rounded-full shadow-2xl shadow-primary/30"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.8, type: 'spring' }}
          />

          <motion.h1
            className="font-display text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black text-primary text-glow tracking-wider mb-4"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, ease: 'easeOut' }}
          >
            {t.hero.title}
          </motion.h1>

          <motion.p
            className="text-lg sm:text-xl md:text-2xl text-foreground/80 mb-3 font-medium"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            {t.hero.subtitle}
          </motion.p>

          <motion.p
            className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {t.hero.description}
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <a
              href="https://discord.gg/yMMAKZfz"
              target="_blank"
              rel="noopener noreferrer"
              className="gradient-primary px-10 py-4 rounded-xl font-display text-base md:text-lg font-bold text-primary-foreground tracking-wide hover:opacity-90 transition-all box-glow animate-pulse-glow flex items-center gap-3 hover:scale-105"
            >
              <Play className="w-5 h-5" />
              {t.hero.joinNow}
            </a>
            <a
              href="#lore"
              className="px-8 py-3.5 rounded-xl text-sm font-semibold border border-primary/30 text-foreground hover:border-primary/60 hover:bg-primary/5 transition-all"
            >
              {t.hero.learnMore}
            </a>
          </motion.div>

          {/* Stats */}
          <motion.div
            className="flex flex-wrap justify-center gap-8 md:gap-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            {stats.map((stat, i) => (
              <AnimatedCounter key={i} target={stat.value} label={stat.label} />
            ))}
          </motion.div>
        </motion.div>

        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <ChevronDown className="w-6 h-6 text-muted-foreground" />
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
