import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';

const RulesSection = () => {
  const { t } = useLanguage();

  const rules = [
    t.rules.rule1, t.rules.rule2, t.rules.rule3,
    t.rules.rule4, t.rules.rule5, t.rules.rule6,
  ];

  return (
    <section id="rules" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/20 to-background" />
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary text-glow-sm mb-2">
            {t.rules.title}
          </h2>
          <p className="text-muted-foreground">{t.rules.subtitle}</p>
        </motion.div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4">
          {rules.map((rule, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="glass rounded-xl p-5 flex gap-4 items-start hover:border-primary/30 transition-colors"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <span className="font-display text-sm font-bold text-primary">{i + 1}</span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">{rule.title}</h3>
                <p className="text-sm text-muted-foreground">{rule.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-8 text-center"
        >
          <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-lg text-sm text-muted-foreground">
            <AlertTriangle className="w-4 h-4 text-primary" />
            {t.rules.subtitle}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default RulesSection;
