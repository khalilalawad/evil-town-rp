import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import LoreSection from '@/components/LoreSection';
import DepartmentsSection from '@/components/DepartmentsSection';
import MapSection from '@/components/MapSection';
import RulesSection from '@/components/RulesSection';
import WhyJoinSection from '@/components/WhyJoinSection';
import AnnouncementsSection from '@/components/AnnouncementsSection';
import GallerySection from '@/components/GallerySection';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <LoreSection />
      <DepartmentsSection />
      <MapSection />
      <RulesSection />
      <WhyJoinSection />
      <AnnouncementsSection />
      <GallerySection />
      <Footer />
    </div>
  );
};

export default Index;
