import { motion } from 'framer-motion';
import { Shield, Swords, AlertTriangle, ArrowLeft } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';

const RulesPage = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20 container mx-auto px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          {t.common.backToHome}
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary text-glow-sm mb-3">{t.rulesPage.title}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">{t.rulesPage.subtitle}</p>
        </motion.div>

        {/* General Rules */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-bold text-foreground">{t.rulesPage.generalRules}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {t.rulesPage.general.map((rule: any, i: number) => (
              <div key={i} className="glass rounded-xl p-5 hover:border-primary/30 transition-colors">
                <div className="flex gap-4 items-start">
                  <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center font-display text-sm font-bold text-primary">{i + 1}</span>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">{rule.title}</h3>
                    <p className="text-sm text-muted-foreground">{rule.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* RP Rules */}
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Swords className="w-5 h-5 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-bold text-foreground">{t.rulesPage.rpRules}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {t.rulesPage.rp.map((rule: any, i: number) => (
              <div key={i} className="glass rounded-xl p-5 hover:border-primary/30 transition-colors">
                <div className="flex gap-4 items-start">
                  <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center font-display text-sm font-bold text-primary">{i + 1}</span>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">{rule.title}</h3>
                    <p className="text-sm text-muted-foreground">{rule.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Punishments */}
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-destructive" />
            </div>
            <h2 className="font-display text-2xl font-bold text-foreground">{t.rulesPage.punishments}</h2>
          </div>
          <div className="glass rounded-xl overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/30">
                  <th className="text-start p-4 font-display text-sm text-primary">Offense</th>
                  <th className="text-start p-4 font-display text-sm text-primary">Penalty</th>
                </tr>
              </thead>
              <tbody>
                {t.rulesPage.punishmentList.map((p: any, i: number) => (
                  <tr key={i} className="border-b border-border/10 last:border-0">
                    <td className="p-4 text-foreground text-sm">{p.offense}</td>
                    <td className="p-4 text-muted-foreground text-sm">{p.penalty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default RulesPage;
