import { motion } from 'framer-motion';
import { ArrowLeft, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/i18n/LanguageContext';
import Navbar from '@/components/Navbar';
import serverMap from '@/assets/server-map.png';

const zoneColors: Record<string, string> = {
  'Government District': 'bg-blue-500/20 text-blue-400',
  'المنطقة الحكومية': 'bg-blue-500/20 text-blue-400',
  'Central City': 'bg-rose-500/20 text-rose-400',
  'وسط المدينة': 'bg-rose-500/20 text-rose-400',
  'Civilian Zone': 'bg-emerald-500/20 text-emerald-400',
  'المنطقة المدنية': 'bg-emerald-500/20 text-emerald-400',
  'Gang Territory': 'bg-red-500/20 text-red-400',
  'منطقة العصابات': 'bg-red-500/20 text-red-400',
  'Commercial District': 'bg-amber-500/20 text-amber-400',
  'المنطقة التجارية': 'bg-amber-500/20 text-amber-400',
};

const MapPage = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20 container mx-auto px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          {t.common.backToHome}
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary text-glow-sm mb-3">{t.mapPage.title}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">{t.mapPage.subtitle}</p>
        </motion.div>

        {/* Full map image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-5xl mx-auto mb-16"
        >
          <div className="glass rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/10">
            <img src={serverMap} alt="Evil Town - Emergency Emden Map" className="w-full h-auto" />
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-5xl mx-auto">
          {t.mapPage.locations.map((loc: any, i: number) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="glass rounded-xl p-6 hover:border-primary/30 transition-colors group"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-foreground mb-1">{loc.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{loc.desc}</p>
                  <span className={`inline-block text-xs px-3 py-1 rounded-full font-medium ${zoneColors[loc.zone] || 'bg-primary/10 text-primary'}`}>
                    {loc.zone}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MapPage;
