import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, CheckCircle, UserPlus } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "@/i18n/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import Navbar from "@/components/Navbar";

type CharacterForm = {
  name: string;
  age: string;
  nationality: string;
  job: string;
  backstory: string;
};

const initialForm: CharacterForm = {
  name: "",
  age: "",
  nationality: "",
  job: "",
  backstory: "",
};

const CharactersPage = () => {
  const { t } = useLanguage();
  const [status, setStatus] = useState<"idle" | "creating" | "success" | "error">("idle");
  const [form, setForm] = useState<CharacterForm>(initialForm);
  const [message, setMessage] = useState("");

  const updateField = (field: keyof CharacterForm, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("creating");
    setMessage("");

    try {
      const response = await fetch("/api/character", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data?.error || "Character submit failed");
      }

      setStatus("success");
      setForm(initialForm);
      setMessage(data?.message || "");
    } catch (error) {
      console.error(error);
      setStatus("error");
      setMessage(t.characters.missingWebhook);
    }
  };

  if (status === "success") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center glass rounded-2xl p-12 max-w-md mx-4">
          <CheckCircle className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
          <h2 className="font-display text-2xl font-bold text-foreground mb-2">{t.characters.successTitle}</h2>
          <p className="text-muted-foreground mb-4">{message || t.characters.successText}</p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Button onClick={() => setStatus("idle")} variant="outline">
              {t.characters.createAnother}
            </Button>
            <Link to="/">
              <Button>{t.common.backToHome}</Button>
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20 container mx-auto px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          {t.common.backToHome}
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary text-glow-sm mb-3">{t.characters.title}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">{t.characters.subtitle}</p>
        </motion.div>

        <motion.form initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">{t.characters.name}</label>
              <Input value={form.name} onChange={(e) => updateField("name", e.target.value)} className="glass" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">{t.characters.age}</label>
              <Input type="number" value={form.age} onChange={(e) => updateField("age", e.target.value)} className="glass" required min="18" max="80" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">{t.characters.nationality}</label>
              <Input value={form.nationality} onChange={(e) => updateField("nationality", e.target.value)} className="glass" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">{t.characters.job}</label>
              <Input value={form.job} onChange={(e) => updateField("job", e.target.value)} className="glass" required />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">{t.characters.backstory}</label>
            <Textarea value={form.backstory} onChange={(e) => updateField("backstory", e.target.value)} className="glass" rows={6} placeholder={t.characters.backstoryPlaceholder} required />
          </div>

          {status === "error" && <p className="text-amber-400 text-sm">{message}</p>}

          <Button type="submit" disabled={status === "creating"} className="w-full gradient-primary font-display tracking-wide">
            <UserPlus className="w-4 h-4" />
            {status === "creating" ? t.characters.creating : t.characters.create}
          </Button>
        </motion.form>
      </div>
    </div>
  );
};

export default CharactersPage;
