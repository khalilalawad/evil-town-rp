import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, CheckCircle, Send, Shield, HeartPulse, Scale, Skull } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "@/i18n/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Navbar from "@/components/Navbar";

type Department = "police" | "ems" | "gang" | "justice";

type FormState = {
  name: string;
  age: string;
  discord: string;
  experience: string;
  whyJoin: string;
  scenario: string;
  backstory: string;
  notes: string;
};

const initialForm: FormState = {
  name: "",
  age: "",
  discord: "",
  experience: "",
  whyJoin: "",
  scenario: "",
  backstory: "",
  notes: "",
};

const ApplicationsPage = () => {
  const { t, lang } = useLanguage();
  const [dept, setDept] = useState<Department | "">("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [form, setForm] = useState<FormState>(initialForm);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const departmentDetails = useMemo(
    () => ({
      police: {
        label: t.applications.police,
        icon: Shield,
        accent: "from-blue-500/30 to-cyan-500/10 border-blue-400/30",
      },
      ems: {
        label: t.applications.ems,
        icon: HeartPulse,
        accent: "from-red-500/30 to-orange-500/10 border-red-400/30",
      },
      justice: {
        label: t.applications.justice,
        icon: Scale,
        accent: "from-amber-500/30 to-yellow-500/10 border-amber-400/30",
      },
      gang: {
        label: t.applications.gang,
        icon: Skull,
        accent: "from-rose-500/30 to-fuchsia-500/10 border-rose-400/30",
      },
    }),
    [t],
  );

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = t.applications.form.required;
    if (!form.age || Number(form.age) < 16) errs.age = t.applications.form.minAge;
    if (!form.discord.trim()) errs.discord = t.applications.form.required;
    if (!form.experience.trim() || form.experience.trim().length < 30) errs.experience = t.applications.form.minExperience;
    if (!form.whyJoin.trim() || form.whyJoin.trim().length < 50) errs.whyJoin = t.applications.form.minLength;
    if (!form.scenario.trim() || form.scenario.trim().length < 50) errs.scenario = t.applications.form.minLength;
    if (dept === "gang" && (!form.backstory.trim() || form.backstory.trim().length < 50)) errs.backstory = t.applications.form.minLength;
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dept || !validate()) return;

    setStatus("submitting");

    try {
      const response = await fetch("/api/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          age: form.age,
          discordId: form.discord,
          experience: form.experience,
          reason: form.whyJoin,
          scenario: form.scenario,
          backstory: form.backstory,
          notes: form.notes,
          department: dept,
        }),
      });

      if (!response.ok) {
        throw new Error("Submit failed");
      }

      setStatus("success");
      setForm(initialForm);
      setErrors({});
      setDept("");
    } catch (error) {
      console.error(error);
      setStatus("error");
    }
  };

  const updateField = (field: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
    if (errors[field]) {
      setErrors((current) => {
        const next = { ...current };
        delete next[field];
        return next;
      });
    }
  };

  if (status === "success") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center glass rounded-2xl p-12 max-w-md mx-4">
          <CheckCircle className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
          <h2 className="font-display text-2xl font-bold text-foreground mb-2">{t.applications.form.success}</h2>
          <p className="text-muted-foreground mb-4">{t.applications.form.successSubtext}</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Button onClick={() => setStatus("idle")}>{t.applications.form.submitAnother}</Button>
            <Link to="/">
              <Button variant="outline">{t.common.backToHome}</Button>
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  const selectedDepartment = dept ? departmentDetails[dept] : null;
  const SelectedIcon = selectedDepartment?.icon;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20 container mx-auto px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          {t.common.backToHome}
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary text-glow-sm mb-3">{t.applications.title}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">{t.applications.subtitle}</p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {(["police", "ems", "justice", "gang"] as Department[]).map((option) => {
              const item = departmentDetails[option];
              const Icon = item.icon;
              const active = dept === option;
              return (
                <button
                  key={option}
                  type="button"
                  onClick={() => setDept(option)}
                  className={`glass rounded-2xl border p-4 text-start transition-all hover:border-primary/40 hover:-translate-y-1 ${
                    active ? "border-primary/60 shadow-lg shadow-primary/10" : "border-border/40"
                  }`}
                >
                  <div className={`rounded-xl border bg-gradient-to-br ${item.accent} p-3 mb-3`}>
                    <Icon className="w-6 h-6 text-foreground" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-foreground">{item.label}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{t.applications.cardDescriptions[option]}</p>
                </button>
              );
            })}
          </div>

          <div className="mb-8">
            <label className="block text-sm font-medium text-foreground mb-2">{t.applications.selectDept}</label>
            <Select value={dept} onValueChange={(value) => setDept(value as Department)}>
              <SelectTrigger className="glass">
                <SelectValue placeholder={t.applications.selectDept} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="police">{t.applications.police}</SelectItem>
                <SelectItem value="ems">{t.applications.ems}</SelectItem>
                <SelectItem value="justice">{t.applications.justice}</SelectItem>
                <SelectItem value="gang">{t.applications.gang}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {dept && (
            <motion.form initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} onSubmit={handleSubmit} className="space-y-5">
              <div className={`glass rounded-2xl border bg-gradient-to-br ${selectedDepartment?.accent} p-5`}>
                <div className={`flex ${lang === "ar" ? "flex-row-reverse" : "flex-row"} items-center gap-3 mb-3`}>
                  {SelectedIcon ? <SelectedIcon className="w-6 h-6 text-primary" /> : null}
                  <h2 className="font-display text-xl font-bold text-foreground">{selectedDepartment?.label}</h2>
                </div>
                <p className="text-sm text-muted-foreground">{t.applications.scenarios[dept]}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.name}</label>
                  <Input value={form.name} onChange={(e) => updateField("name", e.target.value)} className="glass" />
                  {errors.name && <p className="text-destructive text-xs mt-1">{errors.name}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.age}</label>
                  <Input type="number" value={form.age} onChange={(e) => updateField("age", e.target.value)} className="glass" />
                  {errors.age && <p className="text-destructive text-xs mt-1">{errors.age}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.discord}</label>
                <Input value={form.discord} onChange={(e) => updateField("discord", e.target.value)} className="glass" />
                {errors.discord && <p className="text-destructive text-xs mt-1">{errors.discord}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.experience}</label>
                <Textarea value={form.experience} onChange={(e) => updateField("experience", e.target.value)} className="glass" rows={3} />
                {errors.experience && <p className="text-destructive text-xs mt-1">{errors.experience}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.whyJoin}</label>
                <Textarea value={form.whyJoin} onChange={(e) => updateField("whyJoin", e.target.value)} className="glass" rows={4} />
                {errors.whyJoin && <p className="text-destructive text-xs mt-1">{errors.whyJoin}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.scenario}</label>
                <Textarea value={form.scenario} onChange={(e) => updateField("scenario", e.target.value)} className="glass" rows={5} />
                {errors.scenario && <p className="text-destructive text-xs mt-1">{errors.scenario}</p>}
              </div>

              {dept === "gang" && (
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.backstory}</label>
                  <Textarea value={form.backstory} onChange={(e) => updateField("backstory", e.target.value)} className="glass" rows={5} />
                  {errors.backstory && <p className="text-destructive text-xs mt-1">{errors.backstory}</p>}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">{t.applications.form.notes}</label>
                <Textarea value={form.notes} onChange={(e) => updateField("notes", e.target.value)} className="glass" rows={3} />
              </div>

              {status === "error" && <p className="text-destructive text-sm">{t.applications.form.error}</p>}

              <Button type="submit" disabled={status === "submitting"} className="w-full gradient-primary font-display tracking-wide">
                <Send className="w-4 h-4" />
                {status === "submitting" ? t.applications.form.submitting : t.applications.form.submit}
              </Button>
            </motion.form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ApplicationsPage;
