import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/i18n/LanguageContext";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import RulesPage from "./pages/RulesPage.tsx";
import FAQPage from "./pages/FAQPage.tsx";
import GuidePage from "./pages/GuidePage.tsx";
import MapPage from "./pages/MapPage.tsx";
import ApplicationsPage from "./pages/ApplicationsPage.tsx";
import CharactersPage from "./pages/CharactersPage.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/rules" element={<RulesPage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/guide" element={<GuidePage />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="/applications" element={<ApplicationsPage />} />
            <Route path="/characters" element={<CharactersPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
